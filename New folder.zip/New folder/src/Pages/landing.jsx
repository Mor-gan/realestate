import React from "react";
import { Link } from "react-router-dom";
import { useState } from "react";
import "../Styles/landing.css";
import Afrilogo from "../Images/Afrilogo.png";
 import Person from "../Images/Person.png";
 import Group from "../Images/Group.png";
 import instagram from "../Images/instagram.svg";
 import twitter from "../Images/twitter.svg";
 import youtube from "../Images/youtube.svg";
 import facebooki from "../Images/facebooki.svg";
 import Lemon from "../Images/Lemon.png";
 import Vector from "../Images/Vector.png";
 import landingCircle from "../Images/landingCircle.png";
 


const Landing = () => {

  const [userData, setUserData] = useState({
    name: "",
   email: "",
  });

  const handleChange = (e) => {
    setUserData({
      ...userData,
      [e.target.id]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("/api")
    .then((res) => res.json())
    .then((data) => setUserData(...userData));
}

  return (
    <body>
      <div className="firstDiv">
       <div className="logoImage"><img src={Afrilogo} alt=""/></div>
      <div className="groupImage"><img src={Group}  alt=""/></div> 
      </div>
      <div className="secondDiv">
        <div  className="imageDiv"> 
        <div className="circleImage"><img src={landingCircle} alt="" /></div>
          <div className="landingfirst"><p>Get free Ebook,</p></div>
        <div className="landingsecond"><p >Achieve best grade and exam success with ease.</p> </div>
         <div className="personImage">
           <div className="personImagge"><img src={Person}   alt="" /></div>
        <div className="lemonImage"><img src={Lemon}  alt="" /> </div>   
      
         </div> 
        </div>
        <div className="formDiv">
          <form className="landingform" onSubmit={handleSubmit}>
          <p className="landingpara">
              Download your free resource for <br /> superior academic achievement!
            </p>
            <input
              className="landingInput"
              type="text"
              placeholder="Full Name"
              id="name"
              name="name"
              onChange={handleChange}
              required
            />
             <input
              className="landingInput"
              type="@email"
              placeholder="Email"
              id="email"
              name="email"
              onChange={handleChange}
              required
            />
     
     <Link to="thankyou"><button className="landingIbutton" onclick="handleSubmit()">DOWNLOAD NOW</button></Link> 
     <p>Your information is safe with us.</p>  
          </form>
          
       <div className="vectorImage"><img src={Vector}  alt="" /></div> 
      </div>
      </div>
      <footer>
        <div className="firstFooter">
        <div className="landingfooter">
          <p>Copyright &copy; 2019.Afrilearn. All rights reserved </p>
          <a href="https://myafrilearn.com/privacy_policy" target="_blank"> <p>Privacy policy</p></a>  
          <img src={Afrilogo} width={100} height={70} alt=""/>
          <div className="foooterimage">
         <a href="https://www.instagram.com/afrilearn/" target="_blank"> <img src={instagram}  alt="" /></a>
         <a href="https://www.instagram.com/afrilearn/" target="_blank"><img src={facebooki}  alt="" /></a> 
         <a href="https://www.instagram.com/afrilearn/" target="_blank"><img src={twitter}  alt="" /></a> 
         <a href="https://www.instagram.com/afrilearn/" target="_blank"><img src={youtube}  alt="" /></a>  
          </div>
        </div>
        <div className="footerFacebook">   This site is not a part of the Facebook website or Facebook Inc. <br/>
Additionally, This site is NOT endorsed by Facebook in any way.<br/> 
FACEBOOK is a trademark of FACEBOOK, Inc.</div>
</div>
      </footer>
    </body>
  );
}
export default Landing;
