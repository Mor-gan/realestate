import React from "react";
// import { Link } from "react-router-dom";
import "../Styles/thankyou.css";
import Afrilogo from "../Images/Afrilogo.png";
import landingCircle from "../Images/landingCircle.png";
import Group from "../Images/Group.png";
import Rectangle from "../Images/Rectangle.jpg";
import apple from "../Images/apple.jpg";
import google from "../Images/google.jpg";
import Person from "../Images/Person.png";
import Vec from "../Images/Vec.png";
 import instagram from "../Images/instagram.svg";
 import quote from "../Images/quote.png";
import twitter from "../Images/twitter.svg";
 import youtube from "../Images/youtube.svg";
 import facebooki from "../Images/facebooki.svg";
 import two from "../Images/two.png";
 import '../Styles/thankyou.css';

function Thankyou(){
    return(
      <body>
          <div className="firstContainer">
          <div className="mainContainer">
   <div className="thankFirst">
              <div className="thankLogo"><img src={Afrilogo} alt=""/></div>
              <div className="thankCircle"><img src={landingCircle}  alt="" /></div>
              <div className="thankGroup"><img src={Group}  alt=""/></div>
          </div>
          <div className="thankFirstHead">
              <h2>Thank You + Offer</h2>
          </div>
          <div className="thankFistDiv">
              <div className="thankContainer">
                  <div className="thankFirstPara"><p>Congratulations for signing up to download our free eBook.<br/> Kindly click the link in your email for instant access.</p></div>
                  <div className="thankSecondPara"><p>To thank you specially, we are granting you full access to<br/> Complete Primary & Secondary Education on Afrilearn.</p></div> 
                  <div className="thankSecondHead"><h4>Why You’ll <span className="Emoji"> ♥️</span> Afrilearn too…</h4></div>
                  <div>
                      <div className="thankThirdPara">
                           <div><img src={Rectangle} alt="" /></div> 
                          <div><p>50,000+ Official Past Questions & Solutions</p></div>
                      </div>
                      <div className="thankThirdPara">
                           <div><img src={Rectangle}  alt="" /></div> 
                          <div><p>5000+ Curriculum-Relevant Class Notes</p></div>
                      </div>
                      <div className="thankThirdPara">
                           <div><img src={Rectangle}  alt="" /></div> 
                          <div><p>3000+ Curriculum-Relevant Video Lessons</p></div>
                      </div>
                      <div className="thankThirdPara">
                           <div><img src={Rectangle}  alt="" /></div> 
                          <div><p>Gamified fun competitions with weekly cash prizes</p></div>
                      </div>
                      <div className="thankThirdPara">
                           <div><img src={Rectangle}  alt="" /></div> 
                          <div><p>Discover your strength with insightful analytics</p></div>
                      </div>
                      <div className="thankThirdPara">
                           <div><img src={Rectangle} alt="" /></div> 
                          <div><p>Boost your confidence with personalised learning</p></div>
                      </div>
                      <div className="thankThirdPara">
                           <div><img src={Rectangle} alt="" /></div> 
                          <div><p>Achieve best grades, university admission, and success in life.</p></div>
                      </div>
                      <div className="thankThirdHead"><h5>Simply download Afrilearn on Play store or iOS Now! Limited slots available.</h5></div>
                  </div>
                  <div className="thankImages">
                  <div className="thankImagesGoogle"><img src={google} width={150} height={60} alt="" /></div>
                  <div className="thankImagesApple"><img src={apple} width={150} height={40} alt="" /></div>
              </div>
         <a href="http://bit.ly/afrilearnfc" target="_blank"> <button type="submit">JOIN OUR COMMUNITY</button></a>   
              </div>
              <div className="thankSecondDiv">
                  <div className="thankSecondDivPerson"><img src={Person}   alt="" /></div>
                  <div className="thankSecondDivVec"><img src={Vec}  alt="" /></div>
              </div>
          </div>
   </div>
   <div className="testimonialDiv">
              <div><img src={quote} alt="" />
              <h1><b>What People are Saying <br/>About Afrilearn?</b></h1>
               </div>
          <div>  <p><b>Get inspired by these stories</b></p></div>  
              <div className=" contain"  >
                  <div className="card">
                  <div className="card-body">
                  <img src={two}  alt=""/> <p className="card-text">I really like the Afrilearn App. It's nice and it really helped me learn fast.</p>
           <p className="card-text">Joseph Jewel, JSS3 </p>
    <p className="card-text">Student </p>
  </div>
                  </div>
                  <div className="card">
                  <div class="border border-success">
                  <img src={two}  alt=""/> <p className="card-text">Afrilearn has been a helpful one. Very much accurate and reliable. We are really grateful for being a selfless organization as your kind gesture has kept our dreams alive. </p>
    <p className="card-text"><b>Adaeze Happiness, SS3 </b></p>
    <p className="card-text">Student </p>
  </div>
                  </div>
                  <div className="card">
                  <div class="card-body">
                  <img src={two}  alt=""/>  <p className="card-text">I love Afrilearn and it's helping me in teaching my learners</p>
    <p className="card-text">Yusuf Ahmed, Primary 2 </p>
    <p className="card-text">Teacher</p>
  </div>
                  </div>
              </div>
          </div>
          <footer>
        <div className="firstFooter">
        <div className="landingfooter">
          <p>Copyright &copy; 2019.Afrilearn. All rights reserved </p>
          <a href="https://myafrilearn.com/privacy_policy" target="_blank"> <p>Privacy policy</p></a>  
          <img src={Afrilogo} width={100} height={70} alt=""/>
          <div className="foooterimage">
         <a href="https://www.instagram.com/afrilearn/" target="_blank"> <img src={instagram}  alt="" /></a>
         <a href="https://www.instagram.com/afrilearn/" target="_blank"><img src={facebooki}  alt="" /></a> 
         <a href="https://www.instagram.com/afrilearn/" target="_blank"><img src={twitter}  alt="" /></a> 
         <a href="https://www.instagram.com/afrilearn/" target="_blank"><img src={youtube}  alt="" /></a>  
          </div>
        </div>
        <div className="footerFacebook">   This site is not a part of the Facebook website or Facebook Inc. <br/>
Additionally, This site is NOT endorsed by Facebook in any way.<br/> 
FACEBOOK is a trademark of FACEBOOK, Inc.</div>
</div>
      </footer>
          </div>
  
      </body>
    )
}
export default Thankyou